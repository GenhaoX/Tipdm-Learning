model_data.csv为特征处理后的数据；
cosine_similarity_matrix.npy为余弦相似度计算得到的矩阵；
IFRS.py即为印度美食推荐系统，在此文件夹下打开cmd  输入  python IFRS.py  即可成功打开程序；